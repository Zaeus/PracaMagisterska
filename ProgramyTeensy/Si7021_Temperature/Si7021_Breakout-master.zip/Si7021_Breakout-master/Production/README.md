SparkFun <PRODUCT NAME> Production Files
=========================================


These are the production files SparkFun uses for printing PCBs.


License Information
-------------------
This product is open source! 

The hardware is released under [Creative Commons ShareAlike 4.0 International](https://creativecommons.org/licenses/by-sa/4.0/).

Please use, reuse, and modify these files as you see fit. Please maintain attribution to SparkFun Electronics and release anything derivative under the same license.

Distributed as-is; no warranty is given.

- Your friends at SparkFun.
